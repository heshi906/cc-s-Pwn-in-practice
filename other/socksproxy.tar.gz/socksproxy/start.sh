#!/bin/sh
# Add your startup script
export TERM=xterm
# DO NOT DELETE
/home/ctf/pwn
sleep infinity;
