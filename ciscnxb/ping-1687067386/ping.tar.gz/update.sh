#!/bin/sh
chmod 777 ping
mv -f ping /home/ctf/ping
