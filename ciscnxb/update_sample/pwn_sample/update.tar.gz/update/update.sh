#!/bin/sh
chmod 777 pwn
mv -f pwn /pwn/pwn
# OR
# mv -f pwn /home/ctf/pwn

