import enum


class RdataClass(enum.IntEnum):
    ...


IN: RdataClass
