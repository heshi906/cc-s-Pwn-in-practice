import enum


class Flag(enum.IntFlag):
    ...


AA: Flag
QR: Flag
