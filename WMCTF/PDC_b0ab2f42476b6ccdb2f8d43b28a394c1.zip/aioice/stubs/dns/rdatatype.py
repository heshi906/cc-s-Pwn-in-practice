import enum


class RdataType(enum.IntEnum):
    ...


A: RdataType
AAAA: RdataType
ANY: RdataType
