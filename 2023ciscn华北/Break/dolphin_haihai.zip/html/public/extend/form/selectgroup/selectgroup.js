jQuery(function () {
    App.initHelpers(['select2']);
});